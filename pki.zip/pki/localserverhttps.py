from http.server import BaseHTTPRequestHandler, HTTPServer
import ssl
import os

class MyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        message = b"This is my local server (now over HTTPS)"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(message)))
        self.end_headers()
        self.wfile.write(message)

if __name__ == "__main__":
    # Create server on port 8443
    httpd = HTTPServer(("0.0.0.0", 8443), MyHandler)

    # Locate certificate and key files in ~/pki/
    home = os.path.expanduser("~")
    cert_path = os.path.join(home, "pki", "localhost.crt")
    key_path = os.path.join(home, "pki", "localhost.key")

    # Create SSL context and load cert/key
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=cert_path, keyfile=key_path)

    # Wrap the socket with SSL
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

    print("Serving HTTPS on https://localhost:8443")
    httpd.serve_forever()
